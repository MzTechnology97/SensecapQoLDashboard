#!/bin/bash
service=$(cat /var/dashboard/services/dashboard-update | tr -d '\n')

if [[ $service == 'start' ]]; then
  echo 'running' > /var/dashboard/services/dashboard-update
  wget hhttps://raw.githubusercontent.com/MzTechnology97/SensecapQoLDashboard/main/update.sh -O - | sudo bash
fi
