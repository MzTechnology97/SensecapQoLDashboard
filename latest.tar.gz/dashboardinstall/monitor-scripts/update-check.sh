#!/bin/bash
wget --no-cache https://raw.githubusercontent.com/MzTechnology97/SensecapQoLDashboard/main/version -O /var/dashboard/update
